--
-- PostgreSQL database dump
--

-- Dumped from database version 12.19
-- Dumped by pg_dump version 17.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.movimentacoes_estoque DROP CONSTRAINT IF EXISTS movimentacoes_estoque_id_venda_fkey;
ALTER TABLE IF EXISTS ONLY public.movimentacoes_estoque DROP CONSTRAINT IF EXISTS movimentacoes_estoque_id_produto_fkey;
ALTER TABLE IF EXISTS ONLY public.itens_venda DROP CONSTRAINT IF EXISTS itens_venda_id_venda_fkey;
ALTER TABLE IF EXISTS ONLY public.itens_venda DROP CONSTRAINT IF EXISTS itens_venda_id_produto_fkey;
DROP INDEX IF EXISTS public.index_ean13;
DROP INDEX IF EXISTS public.index_descricao_trigram;
DROP INDEX IF EXISTS public.index_codigo_auxiliar;
ALTER TABLE IF EXISTS ONLY public.vendas DROP CONSTRAINT IF EXISTS vendas_pkey;
ALTER TABLE IF EXISTS ONLY public.produtos DROP CONSTRAINT IF EXISTS produtos_pkey;
ALTER TABLE IF EXISTS ONLY public.movimentacoes_estoque DROP CONSTRAINT IF EXISTS movimentacoes_estoque_pkey;
ALTER TABLE IF EXISTS ONLY public.itens_venda DROP CONSTRAINT IF EXISTS itens_venda_pkey;
ALTER TABLE IF EXISTS public.vendas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.produtos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.movimentacoes_estoque ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.itens_venda ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.vendas_id_seq;
DROP TABLE IF EXISTS public.vendas;
DROP SEQUENCE IF EXISTS public.produtos_id_seq;
DROP TABLE IF EXISTS public.produtos;
DROP SEQUENCE IF EXISTS public.movimentacoes_estoque_id_seq;
DROP TABLE IF EXISTS public.movimentacoes_estoque;
DROP SEQUENCE IF EXISTS public.itens_venda_id_seq;
DROP TABLE IF EXISTS public.itens_venda;
DROP EXTENSION IF EXISTS pg_trgm;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: itens_venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itens_venda (
    id integer NOT NULL,
    id_venda integer,
    id_produto integer,
    quantidade numeric(10,3),
    preco_custo numeric(10,2),
    valor_unitario numeric(10,2),
    valor_total numeric(10,2)
);


ALTER TABLE public.itens_venda OWNER TO postgres;

--
-- Name: itens_venda_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.itens_venda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itens_venda_id_seq OWNER TO postgres;

--
-- Name: itens_venda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.itens_venda_id_seq OWNED BY public.itens_venda.id;


--
-- Name: movimentacoes_estoque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movimentacoes_estoque (
    id integer NOT NULL,
    id_produto integer,
    tipo character varying(20),
    quantidade_anterior numeric(10,3),
    quantidade_movimentada numeric(10,3),
    quantidade_nova numeric(10,3),
    data_movimentacao timestamp without time zone,
    id_venda integer,
    observacao text
);


ALTER TABLE public.movimentacoes_estoque OWNER TO postgres;

--
-- Name: movimentacoes_estoque_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.movimentacoes_estoque_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movimentacoes_estoque_id_seq OWNER TO postgres;

--
-- Name: movimentacoes_estoque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.movimentacoes_estoque_id_seq OWNED BY public.movimentacoes_estoque.id;


--
-- Name: produtos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produtos (
    id integer NOT NULL,
    descricao character varying(255),
    ean13 character varying(13),
    codigo_auxiliar character varying(6),
    quantidade numeric(10,3),
    preco_custo numeric(10,2),
    preco_venda numeric(10,2),
    data_cadastro timestamp without time zone,
    ativo boolean DEFAULT true
);


ALTER TABLE public.produtos OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produtos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produtos_id_seq OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produtos_id_seq OWNED BY public.produtos.id;


--
-- Name: vendas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendas (
    id integer NOT NULL,
    data_venda timestamp without time zone,
    valor_total numeric(10,2)
);


ALTER TABLE public.vendas OWNER TO postgres;

--
-- Name: vendas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vendas_id_seq OWNER TO postgres;

--
-- Name: vendas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendas_id_seq OWNED BY public.vendas.id;


--
-- Name: itens_venda id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_venda ALTER COLUMN id SET DEFAULT nextval('public.itens_venda_id_seq'::regclass);


--
-- Name: movimentacoes_estoque id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacoes_estoque ALTER COLUMN id SET DEFAULT nextval('public.movimentacoes_estoque_id_seq'::regclass);


--
-- Name: produtos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos ALTER COLUMN id SET DEFAULT nextval('public.produtos_id_seq'::regclass);


--
-- Name: vendas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendas ALTER COLUMN id SET DEFAULT nextval('public.vendas_id_seq'::regclass);


--
-- Data for Name: itens_venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itens_venda (id, id_venda, id_produto, quantidade, preco_custo, valor_unitario, valor_total) FROM stdin;
\.


--
-- Data for Name: movimentacoes_estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movimentacoes_estoque (id, id_produto, tipo, quantidade_anterior, quantidade_movimentada, quantidade_nova, data_movimentacao, id_venda, observacao) FROM stdin;
\.


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produtos (id, descricao, ean13, codigo_auxiliar, quantidade, preco_custo, preco_venda, data_cadastro, ativo) FROM stdin;
\.


--
-- Data for Name: vendas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendas (id, data_venda, valor_total) FROM stdin;
\.


--
-- Name: itens_venda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.itens_venda_id_seq', 1, false);


--
-- Name: movimentacoes_estoque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.movimentacoes_estoque_id_seq', 1, false);


--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produtos_id_seq', 1, false);


--
-- Name: vendas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendas_id_seq', 1, false);


--
-- Name: itens_venda itens_venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_venda
    ADD CONSTRAINT itens_venda_pkey PRIMARY KEY (id);


--
-- Name: movimentacoes_estoque movimentacoes_estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacoes_estoque
    ADD CONSTRAINT movimentacoes_estoque_pkey PRIMARY KEY (id);


--
-- Name: produtos produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: vendas vendas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendas
    ADD CONSTRAINT vendas_pkey PRIMARY KEY (id);


--
-- Name: index_codigo_auxiliar; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_codigo_auxiliar ON public.produtos USING btree (codigo_auxiliar);


--
-- Name: index_descricao_trigram; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_descricao_trigram ON public.produtos USING gin (descricao public.gin_trgm_ops);


--
-- Name: index_ean13; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_ean13 ON public.produtos USING btree (ean13);


--
-- Name: itens_venda itens_venda_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_venda
    ADD CONSTRAINT itens_venda_id_produto_fkey FOREIGN KEY (id_produto) REFERENCES public.produtos(id);


--
-- Name: itens_venda itens_venda_id_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_venda
    ADD CONSTRAINT itens_venda_id_venda_fkey FOREIGN KEY (id_venda) REFERENCES public.vendas(id);


--
-- Name: movimentacoes_estoque movimentacoes_estoque_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacoes_estoque
    ADD CONSTRAINT movimentacoes_estoque_id_produto_fkey FOREIGN KEY (id_produto) REFERENCES public.produtos(id);


--
-- Name: movimentacoes_estoque movimentacoes_estoque_id_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacoes_estoque
    ADD CONSTRAINT movimentacoes_estoque_id_venda_fkey FOREIGN KEY (id_venda) REFERENCES public.vendas(id);


--
-- PostgreSQL database dump complete
--

